<!DOCTYPE html>
<html>
<head>
	<title><?= $title ?></title>
</head>
<body>


	<p>the Success show<p>

	<footer id="footer">
		<p>Developed by: Pikachu</p>
	</footer>
</body>
</html>