	<?php foreach ($titles as $ti) { ?>
		
		<tr>
			<td> <?= $ti->text ?></td>
		</tr>

	<?php } ?>