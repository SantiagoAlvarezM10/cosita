
	<footer id="footer">
		<p>Developed by: Pikachu</p>
	</footer>
</body>
</html>